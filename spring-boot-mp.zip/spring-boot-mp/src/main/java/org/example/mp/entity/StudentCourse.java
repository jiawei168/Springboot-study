package org.example.mp.entity;

import lombok.Data;

@Data
public class StudentCourse {
    private Long studentId;
    private Long courseId;
}
