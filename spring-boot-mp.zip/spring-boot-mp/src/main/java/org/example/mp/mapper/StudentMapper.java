package org.example.mp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.example.mp.entity.Student;

public interface StudentMapper extends BaseMapper<Student> {

}
