package org.example.mp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Select;
import org.example.mp.entity.Course;
import org.example.mp.entity.CourseStudent;
import org.example.mp.entity.Student;

import java.util.List;

public interface CourseStudentMapper extends BaseMapper<CourseStudent> {
    @Select("SELECT s.* FROM student s INNER JOIN t_course_student tcs ON s.id = tcs.student_id WHERE tcs.student_id = #{studentId}")
    List<Student> selectStudentsByCourseId(Long courseId);
}
