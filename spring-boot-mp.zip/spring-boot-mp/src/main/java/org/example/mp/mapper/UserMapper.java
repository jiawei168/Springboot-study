package org.example.mp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.example.mp.entity.User;

public interface UserMapper extends BaseMapper<User> {
}
