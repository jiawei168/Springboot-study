package org.example.mp.entity;

import lombok.Data;

@Data
public class Teacher {
    private Long id;
    private String name;
}